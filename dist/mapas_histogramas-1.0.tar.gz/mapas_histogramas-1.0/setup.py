from setuptools import setup

setup (

	name="mapas_histogramas",
	version="1.0",
	description="Construye mapas e histogramas de sismicidad",
	author="Miguel Lizarazo",
	packages=["mapas_histogramas"]

	)